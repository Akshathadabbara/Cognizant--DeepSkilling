import { useEffect,useState } from "react";
import "./App.css";

function App(){

  const [users,setUsers]=useState([]);

  useEffect(()=>{

    fetch("https://jsonplaceholder.typicode.com/users")
    .then(res=>res.json())
    .then(data=>setUsers(data));

  },[]);

  return(

    <div className="container">

      <h1>Fetch API</h1>

      {
        users.map(user=>(
          <div className="card" key={user.id}>
            <h3>{user.name}</h3>
            <p>{user.email}</p>
          </div>
        ))
      }

    </div>

  );

}

export default App;