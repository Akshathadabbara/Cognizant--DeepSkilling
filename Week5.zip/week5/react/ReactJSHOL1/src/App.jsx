import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>Welcome to React</h1>

      <h2>Cognizant Java FSE - Week 5</h2>

      <p>This is my first React Single Page Application.</p>

      <h3>Developed By</h3>

      <h2>Koneti Dheeraj Kumar</h2>

      <button>Start Learning React</button>
    </div>
  );
}

export default App;