import "./App.css";

function App() {

  const name = "Dheeraj Kumar";
  const course = "React";
  const year = 2026;

  const greet = () => {
    return "Welcome to React ES6 & JSX";
  };

  return (
    <div className="container">

      <h1>{greet()}</h1>

      <h2>Student Details</h2>

      <p>Name : {name}</p>

      <p>Course : {course}</p>

      <p>Year : {year}</p>

      <p>Current Year : {new Date().getFullYear()}</p>

      <p>5 + 10 = {5 + 10}</p>

    </div>
  );
}

export default App;