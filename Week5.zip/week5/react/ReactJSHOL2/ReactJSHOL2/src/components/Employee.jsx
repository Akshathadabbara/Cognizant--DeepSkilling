function Employee(props) {
  return (
    <div className="card">
      <h2>Employee Details</h2>

      <p><b>ID:</b> {props.id}</p>

      <p><b>Name:</b> {props.name}</p>

      <p><b>Department:</b> {props.department}</p>

      <p><b>Salary:</b> ₹{props.salary}</p>
    </div>
  );
}

export default Employee;