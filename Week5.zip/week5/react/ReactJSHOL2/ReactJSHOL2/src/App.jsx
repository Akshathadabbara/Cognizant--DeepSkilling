import Employee from "./components/Employee";
import "./App.css";

function App() {
  return (
    <div className="App">

      <h1>React Components and Props</h1>

      <Employee
        id="101"
        name="Dheeraj Kumar"
        department="AI & ML"
        salary="50000"
      />

      <Employee
        id="102"
        name="Rahul"
        department="Java"
        salary="45000"
      />

      <Employee
        id="103"
        name="Sneha"
        department="React"
        salary="55000"
      />

    </div>
  );
}

export default App;