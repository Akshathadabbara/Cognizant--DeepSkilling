import { useState } from "react";
import "./App.css";

function App() {

  const [student, setStudent] = useState("");
  const [students, setStudents] = useState([]);

  const addStudent = () => {

    if(student.trim()===""){
      alert("Please Enter Student Name");
      return;
    }

    setStudents([...students, student]);

    setStudent("");

  };

  const removeStudent = (index) => {

    const newList = students.filter((_, i) => i !== index);

    setStudents(newList);

  };

  return (

    <div className="container">

      <h1>Student Management System</h1>

      <input
        type="text"
        placeholder="Enter Student Name"
        value={student}
        onChange={(e)=>setStudent(e.target.value)}
      />

      <button onClick={addStudent}>
        Add Student
      </button>

      <table>

        <thead>

          <tr>
            <th>S.No</th>
            <th>Student Name</th>
            <th>Action</th>
          </tr>

        </thead>

        <tbody>

        {
          students.map((name,index)=>(

            <tr key={index}>

              <td>{index+1}</td>

              <td>{name}</td>

              <td>

                <button
                  className="delete"
                  onClick={()=>removeStudent(index)}
                >
                  Delete
                </button>

              </td>

            </tr>

          ))
        }

        </tbody>

      </table>

    </div>

  );
}

export default App;