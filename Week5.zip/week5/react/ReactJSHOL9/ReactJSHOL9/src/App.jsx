import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function App() {

  const [users, setUsers] = useState([]);

  useEffect(() => {

    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.log(error);
      });

  }, []);

  return (
    <div className="container">

      <h1>React Axios Example</h1>

      {
        users.map((user) => (

          <div className="card" key={user.id}>

            <h2>{user.name}</h2>

            <p>Email : {user.email}</p>

            <p>Phone : {user.phone}</p>

            <p>Company : {user.company.name}</p>

          </div>

        ))
      }

    </div>
  );
}

export default App;